import { initForm } from './form';
import './styles.css';
import 'zizi-card';

window.addEventListener('DOMContentLoaded', () => {
    initForm();
});